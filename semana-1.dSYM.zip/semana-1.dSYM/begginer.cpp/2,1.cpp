#include <iostream>

int main() {
    int c = 0, thisIsAVariable = 0, q76354 = 0, number = 0;

    std::cout << "Enter an integer: ";
    
    int value; 
    std::cin >> value; 
    std::cout << value + 10 << std::endl;

    if (value > 15) { 
        value -= 5; 
        std::cout << value << std::endl; 
    }

    std::cout << "This is a C++ program" << std::endl;

    std::cout << "This is a C++\nprogram" << std::endl;

    std::cout << "This\nis\na\nC++\nprogram" << std::endl;

    std::cout << "This\tis\ta\tC++\tprogram" << std::endl;

    return 0;
}
