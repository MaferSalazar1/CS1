#include <iostream>

int main() {
    int num1, num2, num3, num4, num5;

    std::cout << "Enter five integers: ";
    std::cin >> num1 >> num2 >> num3 >> num4 >> num5;

    int largest = num1;
    int smallest = num1;

    if (num2 > largest) largest = num2;
    if (num3 > largest) largest = num3;
    if (num4 > largest) largest = num4;
    if (num5 > largest) largest = num5;

    if (num2 < smallest) smallest = num2;
    if (num3 < smallest) smallest = num3;
    if (num4 < smallest) smallest = num4;
    if (num5 < smallest) smallest = num5;

    std::cout << "Largest is " << largest << std::endl;
    std::cout << "Smallest is " << smallest << std::endl;

    return 0;
}
