#include <iostream>

int main() {
    int num1, num2, num3;

    std::cout << "Enter three integers: ";
    std::cin >> num1 >> num2 >> num3;

    if (num3 % num1 == 0)
        std::cout << num1 << " is a factor of " << num3 << std::endl;
    else
        std::cout << num1 << " is not a factor of " << num3 << std::endl;

    if (num3 % num2 == 0)
        std::cout << num2 << " is a factor of " << num3 << std::endl;
    else
        std::cout << num2 << " is not a factor of " << num3 << std::endl;

    return 0;
}
