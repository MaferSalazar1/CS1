#include <iostream>

int main() {
    std::cout << "Face length    Surface area   Volume\n";
    std::cout << "of cube (cm)   of cube (cm^2) of cube (cm^3)\n";

    for (int length = 0; length <= 4; ++length) {
        int surface_area = 6 * length * length;
        int volume = length * length * length;
        std::cout << length << "\t\t" << surface_area << "\t\t" << volume << std::endl;
    }

    return 0;
}
