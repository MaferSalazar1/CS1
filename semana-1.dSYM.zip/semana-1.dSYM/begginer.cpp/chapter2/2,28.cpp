#include <iostream>

int main() {
    int number;

    std::cout << "Enter a four-digit integer: ";
    std::cin >> number;

    int digit1 = number % 10;
    number /= 10;

    int digit2 = number % 10;
    number /= 10;

    int digit3 = number % 10;
    number /= 10;

    int digit4 = number;

    std::cout << digit1 << "  " << digit2 << "  " << digit3 << "  " << digit4 << std::endl;

    return 0;
}
