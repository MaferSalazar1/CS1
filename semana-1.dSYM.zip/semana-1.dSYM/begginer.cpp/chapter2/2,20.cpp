#include <iostream>

int main() {
    int radius;

    std::cout << "Enter the radius of the circle: ";
    std::cin >> radius;

    std::cout << "Diameter is " << 2 * radius << std::endl;
    std::cout << "Circumference is " << 2 * 3.14159 * radius << std::endl;
    std::cout << "Area is " << 3.14159 * radius * radius << std::endl;

    return 0;
}
