#include <iostream>

int main() {
    char character;

    std::cout << "Enter a character: ";
    std::cin >> character;

    std::cout << "The integer equivalent of '" << character << "' is " << static_cast<int>(character) << std::endl;

    return 0;
}
