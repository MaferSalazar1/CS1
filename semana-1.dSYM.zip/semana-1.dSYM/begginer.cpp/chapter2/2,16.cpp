#include <iostream>

int main() {
    float num1, num2;

    std::cout << "Enter the first number: ";
    std::cin >> num1;

    std::cout << "Enter the second number: ";
    std::cin >> num2;

    float sum = num1 + num2;
    float product = num1 * num2;
    float difference = num1 - num2;
    float quotient = num1/num2;

    std::cout << "Sum: " << sum << "\n";
    std::cout << "Product: " << product << "\n";
    std::cout << "Difference: " << difference << "\n";
    std::cout<< "Quotient: " << quotient << "\n";

    return 0;
}
