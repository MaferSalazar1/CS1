#include <iostream>

int main() {
    std::cout << " CCC    +      +\n";
    std::cout << "C       +      +\n";
    std::cout << "C    ++++++ ++++++\n";
    std::cout << "C       +      +\n";
    std::cout << " CCC    +      +\n";

    return 0;
}
