#include <iostream>

int main() {
    int num1, num2;

    std::cout << "Enter two integers: ";
    std::cin >> num1 >> num2;

    if (num1 % 2 == 0)
        std::cout << num1 << " is even." << std::endl;
    else
        std::cout << num1 << " is odd." << std::endl;

    if (num2 % 2 == 0)
        std::cout << num2 << " is even." << std::endl;
    else
        std::cout << num2 << " is odd." << std::endl;

    int sum = num1 + num2;
    if (sum % 2 == 0)
        std::cout << "Sum of the numbers (" << sum << ") is even." << std::endl;
    else
        std::cout << "Sum of the numbers (" << sum << ") is odd." << std::endl;

    return 0;
}
